package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        String emp_name;
        long salary;
        int emp_birth_date;
        String emp_birth_month;
        int emp_birth_year;
        int emp_age;

        Scanner sc=new Scanner(System.in);

        System.out.println("Employee name: ");
        emp_name=sc.nextLine();

        System.out.println("Employee Salary: ");
        salary=sc.nextLong();

        System.out.println("Employee birth date: ");
        emp_birth_date=sc.nextInt();
        sc.nextLine();

        System.out.println("Employee birth month: ");
        emp_birth_month=sc.nextLine();

        System.out.println("Employee birth year: ");
        emp_birth_year=sc.nextInt();

        emp_age=2020-emp_birth_year;

        if(salary>=500000){
            System.out.println("Name"+emp_name);
            System.out.println("Age"+emp_age);
            System.out.println("Salary"+salary);
            System.out.println("You have to pay 20% tax");

        }else if(salary>=400000 && salary<500000){
            System.out.println("Name"+emp_name);
            System.out.println("Age"+emp_age);
            System.out.println("Salary"+salary);
            System.out.println("You have to pay 15% tax");

        }else if(salary>=300000 && salary<400000){
            System.out.println("Name"+emp_name);
            System.out.println("Age"+emp_age);
            System.out.println("Salary"+salary);
            System.out.println("You have to pay 10% tax");

        }else if(salary>=200000 && salary<300000){
            System.out.println("Name: "+emp_name);
            System.out.println("Age: "+emp_age);
            System.out.println("Salary: "+salary);
            System.out.println("You have to pay 5% tax");

        }else{
            System.out.println("Name"+emp_name);
            System.out.println("Age"+emp_age);
            System.out.println("Salary"+salary);
            System.out.println("No tax");
        }

    }
}
