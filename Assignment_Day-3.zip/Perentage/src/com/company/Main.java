package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

       float percentage;
       float mark;
       float maths;
       float science;
       float malayalam;
       float english;
       float hindi;

        Scanner sc=new Scanner(System.in);
        System.out.println("Mark in Maths: ");
        maths=sc.nextFloat();

        System.out.println("Mark in Science: ");
        science=sc.nextFloat();

        System.out.println("Mark in Malayalam: ");
        malayalam=sc.nextFloat();

        System.out.println("Mark in Hindi: ");
        hindi=sc.nextFloat();

        System.out.println("Mark in English: ");
        english=sc.nextFloat();

        mark=maths+science+malayalam+hindi+english;
        percentage=(mark/500)*100;

        System.out.println(mark);
        System.out.println(percentage);

        if(percentage>=90){
            System.out.println("Your percentage is "+percentage);
            System.out.println("You have A grade");

        }else if(percentage>=70 && percentage<90){
            System.out.println("Your percentage is "+percentage);
            System.out.println("You have B grade");

        }else if(percentage>=50 && percentage<70){
            System.out.println("Your percentage is "+percentage);
            System.out.println("You have C grade");

        }else if(percentage>=30 && percentage<50){
            System.out.println("Your percentage is "+percentage);
            System.out.println("You have D grade");

        }else{
            System.out.println("You are failed");
        }

    }
}
